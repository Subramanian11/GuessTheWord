package game;

import java.util.Random;

/**
 * Class which holds all random words.
 * @author K. Subramanian
 * @date 20/09/2023
 */
public class Words {

	/**
	 * holds all random words in a list
	 */
	private String[] randomWords = {"Air","Fire","Water","Sky","Land"};

	/**
	 * holds the word with the given index
	 */
	private String selectedWord;
	
	/*
	 * instance for Random.
	 */
	private Random random = new Random();
	
	/**
	 * to hold the array of letters of selected item 
	 * e.g. --a--- if 3 rd letter a then remaining letter finding.
	 */
	private char[] letters; 
	
	/**
	 * Default constructor to set value for selectedWord
	 *  with random value according array length-1
	 */
	public Words() {
		selectedWord = randomWords[random.nextInt(randomWords.length)];
		letters = new char[selectedWord.length()];
	}
	

	public void quiz() {
		
		System.out.println("----------------------------------------------------------");
		System.out.println("Quiz on 'Master of Five Elements'");
		System.out.println("----------------------------------------------------------");
		
		if(selectedWord.equals("Fire")) {
			System.out.println("Signifies energy, transformation, and passion.");
		}
		else if(selectedWord.equals("Water")) {
			System.out.println("Symbolizes fluidity, adaptability, and emotions.");
		}
		else if(selectedWord.equals("Air")) {
			System.out.println("Represents intellect, communication, and thought.");
		}
		else if(selectedWord.equals("Land")) {
			System.out.println("Represents stability, grounding, and physical presence.");
		}
		else if(selectedWord.equals("Sky")){
			System.out.println("This element is sometimes considered the quintessence, representing the spiritual or cosmic aspect of existence. It is often seen as the source of all other elements.");
		}
	}


	/**
	 * To string method
	 */
	@Override
	public String toString() {
		
		StringBuilder text = new StringBuilder();
		
		for(char letter:letters) {
			if(letter=='\u0000') {
				text.append('-');
			}
			else {
				text.append(letter);
			}
			text.append(' ');
		}
		return text.toString();
	}
	
	public boolean isGuessedRight() {
		
		for(char letter:letters) {
			if(letter=='\u0000') {
				return false;
			}
		}
		return true;
	}

	public boolean guess(char letter) {
		// TODO Auto-generated method stub
		
		boolean guessedRight = false;
		for(int i=0;i<selectedWord.length();i++) {
			
			if(letter==selectedWord.charAt(i)) {
				letters[i]=letter;
				guessedRight=true;
			}
		}
		return guessedRight;
		
	}
}
