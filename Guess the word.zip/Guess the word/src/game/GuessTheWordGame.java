package game;

import java.util.Scanner;

/**
 * A word guessing game that tasks the player with correctly selecting a random word.
 * @author K. Subramanian
 * @date 20/09/2023
 */
public class GuessTheWordGame {

	/**
	 * loop condition variable
	 */
	private boolean play=true;
	
	/**
	 *holds the random word from toString method
	 */
	private Words randomWord = new Words();
	
	/**
	 * Getting user input class instance
	 */
	private Scanner scan = new Scanner(System.in);
	
	/**
	 * chance variable
	 */
	private int chances =3;
	
	private char lastRound;
	
	public GuessTheWordGame() {
		
		randomWord.quiz();
	}
	
	/**
	 *  Method to start the game
	 */
	public void start() {
		
		do {
			showWord();
			getInput();
			checkInput();
		}while(play);
	}
	
	
	/**
	 * Method of showWord
	 */
	void showWord() {
		System.out.println("You have "+chances+" tries left.");
		System.out.println(randomWord);
	}
	
	/**
	 * Method of getInput
	 */
	void getInput() {
	
		System.out.println("Enter a letter to guess the word: ");
		String userGuess = scan.nextLine();
		lastRound = userGuess.charAt(0);
	}
	
	/**
	 * Method of checkInput
	 */
	void checkInput() {
		
		boolean isGuessedRight = randomWord.guess(lastRound);
		
		if(isGuessedRight) {
		if(randomWord.isGuessedRight()) {
			System.out.println("Congrats, you won!");
			System.out.println("The Word is : "+randomWord);
			play=false;
		}
		}
		else {
			chances-=1;
			if(chances==0) {
				System.out.println("-----------------------------bye bye-----------------------------");
				System.out.println("Game Over !");
				play=false;
			}
		}
	}
	
	/**
	 * Scanner close method
	 */
	public void end() {
		scan.close();
	}
}
